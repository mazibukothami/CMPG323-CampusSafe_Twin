import { useState } from 'react';
import { Sidebar } from '../../components/common/Sidebar';
import { MapView } from '../../components/map/MapView';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend,
} from 'recharts';
import { mockIncidents } from '../../services/api';

const COLORS = ['#EF4444', '#F59E0B', '#3B82F6', '#10B981', '#8B5CF6', '#6B7280'];

export const Analytics = () => {
  const [incidents] = useState(mockIncidents);

  // Category breakdown
  const categoryData = Object.entries(
    incidents.reduce((acc, i) => {
      acc[i.category] = (acc[i.category] || 0) + 1;
      return acc;
    }, {} as Record<string, number>)
  ).map(([name, value]) => ({ name, value }));

  // Trend data (mock)
  const trendData = [
    { time: '00:00', incidents: 2 },
    { time: '04:00', incidents: 1 },
    { time: '08:00', incidents: 5 },
    { time: '12:00', incidents: 8 },
    { time: '16:00', incidents: 6 },
    { time: '20:00', incidents: 4 },
  ];

  return (
    <div className="flex h-screen bg-gray-50">
      <Sidebar role="security" />

      <main className="flex-1 overflow-y-auto p-6">
        <h1 className="text-2xl font-bold text-nwu-blue mb-6">Analytics & Hotspots</h1>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          <div className="bg-white rounded-xl shadow-sm p-6">
            <h2 className="font-semibold text-gray-900 mb-4">Incidents by Category</h2>
            <ResponsiveContainer width="100%" height={250}>
              <PieChart>
                <Pie
                  data={categoryData}
                  cx="50%"
                  cy="50%"
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                  label
                >
                  {categoryData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </div>

          <div className="bg-white rounded-xl shadow-sm p-6">
            <h2 className="font-semibold text-gray-900 mb-4">Incidents by Time</h2>
            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={trendData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="time" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="incidents" fill="#003366" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm p-4">
          <h2 className="font-semibold text-gray-900 mb-4">Hotspot Map</h2>
          <MapView incidents={incidents} height="500px" />
        </div>
      </main>
    </div>
  );
};