import { useState } from "react";
import { Sidebar } from "../../components/common/Sidebar";
import { MapView } from "../../components/map/MapView";
import { StatusBadge } from "../../components/common/StatusBadge";
import { mockIncidents } from "../../services/api";
import { Bell, AlertCircle, CheckCircle } from "lucide-react";

export const SecurityDashboard = () => {
  const [incidents] = useState(mockIncidents);
  const stats = {
    total: incidents.length,
    active: incidents.filter((i) => i.status !== "resolved").length,
    resolved: incidents.filter((i) => i.status === "resolved").length,
  };
  return (
    <div className="flex h-screen bg-gray-50">
      <Sidebar role="security" />
      <main className="flex-1 overflow-y-auto">
        <header className="bg-white border-b px-6 py-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold text-nwu-blue">
            {" "}
            Security Dashboard
          </h1>
          <div className="flex items-center gap-4">
            <Bell className="w-6 h-6 text-gray-600" />
            <div className="w-10 h-10 rounded-full bg-nwu-blue text-white flex items-center justify-center font-semibold">
              S
            </div>
          </div>
        </header>

        <section className="p-6 grid grid-cols-3 gap-4">
          <div className="bg-white p-6 rounded-xl shadow-sm">
            <AlertCircle className="w-8 h-8 text-red-500 mb-2" />
            <p className="text-3xl font-bold text-gray-900">{stats.total}</p>
            <p className="text-sm text-gray-500">Total Incidents</p>
          </div>
          <div className="bg-white p-6 rounded-xl shadow-sm">
            <AlertCircle className="w-8 h-8 text-yellow-500 mb-2" />
            <p className="text-3xl font-bold text-gray-900">{stats.active}</p>
            <p className="text-sm text-gray-500">Active</p>
          </div>
          <div className="bg-white p-6 rounded-xl shadow-sm">
            <CheckCircle className="w-8 h-8 text-green-500 mb-2" />
            <p className="text-3xl font-bold text-gray-900">{stats.resolved}</p>
            <p className="text-sm text-gray-500">Resolved Today</p>
          </div>
        </section>

        <section className="p-6 grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-white rounded-xl shadow-sm p-4">
            <h2 className="font-semibold mb-4 text-gray-900">
              Live Incident Feed
            </h2>
            <div className="space-y-3 max-h-96 overflow-y-auto">
              {incidents.map((incident) => (
                <div
                  key={incident.id}
                  className="border border-gray-200 rounded-lg p-3 hover:bg-gray-50 cursor-pointer"
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-medium capitalize text-gray-900">
                      {incident.category}
                    </span>
                    <StatusBadge status={incident.status} />
                  </div>
                  <p className="text-sm text-gray-600">
                    {incident.description}
                  </p>
                  <p className="text-xs text-gray-400 mt-1">
                    {new Date(incident.reportedAt).toLocaleString()}
                  </p>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-sm p-4">
            <h2 className="font-semibold mb-4 text-gray-900">Campus Map</h2>
            <MapView incidents={incidents} height="400px" />
          </div>
        </section>
      </main>
    </div>
  );
};