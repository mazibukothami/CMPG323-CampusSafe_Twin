import {useNavigate} from 'react-router-dom';
import {CheckCircle} from 'lucide-ract';
import {Button} from '../../components/common/Button';

export const IncidentReported = () =>{
    const navigate = useNavigate();
    const referenceNumber = 'CS-2026-${Math.floor(1000 + Math.random()*9000)}';
    return(
        <div className="min-h-screen bg-gray-50 flex items-center justify-center p-6">
            <div className="bg-white rounded-2xl shadow-lg p-12 max-w-md w-full text-center">
                <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
                    <CheckCircle className="w-12 h-12 text-gray-900 mb-2"/>
                    <h1 className="text-2xl font-bold text-gray-900 mb-2">
                        Incident reported
                        </h1>
                        <p className="text-gray-500 mb=6">
                            Thank you for helping keep campus safe.
                            </p>

                            <div className="bg-gray-50 rounded-lg p-4 mb-6">
                                <p className="text-sm text-gray-500 mb-1">Reference Number</p>
                                <p className="text-xl font-bold text-nwu-blue">{referenceNumber}</p>
                                </div>

                                <Button 
                                    onClick={() => navigate('/student')}
                                    className="w-full py-3">
                                        Return to Dashboard
                                        </Button>
                                        </div>
                                        </div>
    );
};