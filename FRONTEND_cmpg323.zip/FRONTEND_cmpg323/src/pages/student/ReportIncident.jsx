import {useState} from 'react';
import {useNavigate} from 'react-router-dom';
import {Sidebar} from '../../components/common/Sidebar';
import {MapView} from '../../components/map/MapView';
import {Button} from '../../components/common/Button';
import {INCIDENT_CATEGORIES} from '../../utils/constants';
import toast from 'react-hot-toast';

export const ReportIncident = () => {
    const navigate = useNavigate();
    const [category, setCategory()] = useState('');
    const [description, setDescription()] =useState('');
    const [position, setPosition] = useState<[number, number] | null>(null);
    const [photo, setPhoto] = useState<File | null>(null);
    const handleSubmit=(e: React.FormEvent) => {
        e.preventDefault();
        if (!category || !description || !position){
            toast.error('Please fill in all required fields');
            return;
        }
        toast.success('Incident reported successfully!');
        navigate('/student/reported');
    };
    return(
        <div className="flex h-screen bg-gray-50">
            <Sidebar role="student"/>
            <main className="flex-1 overflow-y-auto p-6">
                <h1 className="text-2xl font-bold text-nwu-blue mb-6">Report an Incident</h1>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <form onSubmit={handleSubmit} className="bg-white rounnded-xl shadow-sm p-6 space-y-4">
                        <div>
                            <label className="block text-sm font-medium text-gray-700 mb-1">
                                Incident Report * 
                                </label>
                                <select
                                    value={category}
                                    onChange={(e) => setCategory(e.target.value)}
                                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-nwu-blue"
                                    required>
                                        <option value="">Select a category</option>
                                        {INCIDENT_CATEGORIES.map(cat =>(
                                            <option key={cat.value} value={cat.value}>{cat.label}</option>
                                        ))}
                                        </select>
                                        </div>
                                        <div>
                                            <label className="block text-sm font-medium text-gray-700 mb-1">
                                                Description *
                                                </label>
                                                <textarea 
                                                    value={description}
                                                    onChange={(e) => setDescription(e.target.value)}
                                                    row= {4}
                                                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-nwu-blue"
                                                    placeholder="Describe what happened?"
                                                    required/>
                                                    </div>
                                                    
                                                    <div>
                                                        <label className="block text-sm font-medium text-gray-700 mb-1">
                                                            Photo (optional)
                                                            </label>
                                                            <input  
                                                                type="file"
                                                                accept="image/jpeg,image/png"
                                                                onChange={(e) => setPhoto(e.target.files?.[0] || null)}
                                                                className="w-full px-4 py-3 border border-gray-300 rounded-lh"/>
                                                                </div>

                                                                <div className="text-sm text-gray-500">
                                                                    {position
                                                                    ? 'Location: ${position[0].toFixed(4)}, ${position[1].toFixed(4)}'
                                                                    : 'Click on the map to set the incident location'}
                                                                    </div>

                                                                    <Button type="submit" className="w-full py-3">
                                                                        Submit Report
                                                                        </Button>
                                                                        </form>

                                                                        <div className="bg-white rounded-xl shadow-sm p-4">
                                                                            <MapView
                                                                                height="500px"
                                                                                onMapClick={(lat, lng) => setPosition([lat, lng])}
                                                                                selectedPosition={position}/>
                                                                                </div>
                                                                                </div>
                                                                                </main>
                                                                                </div>
    );
};