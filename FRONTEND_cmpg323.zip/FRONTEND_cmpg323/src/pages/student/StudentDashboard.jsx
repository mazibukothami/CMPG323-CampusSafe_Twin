import {useState} from 'react';
import {Link} from 'react-router-dom';
import {AlertTriangle, Route, Bell} from 'lucide-react';
import {Sidebar} from '../../components/common/Sidebar';
import {MapView} from '../../components/map/MapView';
import {IncidentCard} from '../../components/incidents/IncidentCard';
import {mockIncidents} from '../../services/api';

export const StudentDashboard = () => {
    const [incidents] = useState(mockIncidents);
    return (
        <div className="flex h-screen bg-gray-50">
            <Sidebar role="student"/>
            <main className="flex-1 overflow-y-auto">
                <header className="bg-white border-b px-6 py-4 flex justify-between items-center">
                    <h1 className="text-2xl font-bold text-nwu-blue">Hello, Alira</h1>
                    <div className="flex items-center gap-4">
                        <Bell className="w-6 h-6 text-gray-600"/>
                    <div className="w-10 h-10 rounded-full bg-nwu-blue text-white flex items-center justify-center font-semibold">
                        A
                        </div>
                    </div>
                    </header>
                
                <section className="p-6 grid grid-cols-1 md:grid-cols-3 gap-4">
                    <Link to="/student/report" className="bg-white p-6 rounded-xl shadow-sm hover:shadow-md transition">
                    <AlertTriangle className="w-8 h-8 text-red-500 mb-2"/>
                    <h3 className="font-semibold text-gray-900">Report an Incident</h3>
                    <p className="text-sm text-gray-500">Quick and confidential</p>
                    </Link>

                    <Lik to="/student/safe-route" className="bg-white p-6 rounded-xl shadow-sm hover:shadow-md transition">
                    <Route className="w-8 h-8 text-blue-500 mb-2"/>
                    <h3 className="font-semibold text-gray-900">Safe Route</h3>
                    <p className="text-sm text-gray-500">Find a safer path</p>
                    </Link>

                    <div className="bg-white p-6 rounded-xl shadow-sm">
                        <Bell className="w-8 h-8 text-yellow-500 mb-2"/>
                        <h3 className="font-semibold text-gray-900">Campus Alerts</h3>
                        <p className="text-sm text-gray-500">2 active alerts</p>
                        </div>
                        </section>

                <section className="p-6 grid grid-cols-1 lg:grid-cols2 gap-6">
                    <div className="bg-white rounded-xl shadow-sm p-4">
                        <h2 className="font-semibold mb-4 text-gray-900">Campus Map</h2>
                        <MapView incidents={incidents} height="400px"/>
                        </div>

                        <div className="bg-white rounded-xl shadow-sm p-4">
                            <h2 className="font-semibold mb-4 text-gray-900">Recent Incidents</h2>
                            <div className="space-y-3">{incidents.map(incident => (
                                <IncidentCard key={incident.id} incident={incident}/>
                            ))}

                            </div>
                            </div>
                            </section>
                            </main>
                            </div>
    );
};