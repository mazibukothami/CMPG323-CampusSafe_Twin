import {useState} from 'react';
import {Sidebar} from '../../components/common/Sidebar';
import {MapView} from '../../components/map/MapView';
import {Button} from '../../components/common/Button';
import {ROUTE_WARNING} from '../../utils/constants';
import {AlertTriangle} from 'lucide-react';

export const SafeRoute = () => {
    const [origin, setOrigin] = useState<[number, number] | null>(null);
    const [destination, setDestination] = useState<[number,number] | null>(null);
    const [route, setRoute] = useState<[number,number][] | null>(null);
    const handleCalculate = () => {
        if(!origin || !destination) 
            return;

    //mock rouute -replace with API call
    setRoute([origin, destination]);
    };
    return (
        <div className="flex h-screen bg-gray-50">
            <Sidebar role="student"/>
            <main className="flex-1 overflow-y-auto p-6">
            <h1 className="text-2xl font-bold text-nwu-blue mb-6">Safe Route</h1>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="bg-white rounded-xl shadow-sm p-6 space-y"
    );
};import {useState} from 'react';
import {Sidebar} from '../../components/common/Sidebar';
import {MapView} from '../../components/map/MapView';
import {Button} from '../../components/common/Button';
import {ROUTE_WARNING} from '../../utils/constants';
import {AlertTriangle} from 'lucide-react';

export const SafeRoute = () => {
    const [origin, setOrigin] = useState<[number, number] | null>(null);
    const [destination, setDestination] = useState<[number,number] | null>(null);
    const [route, setRoute] = useState<[number,number][] | null>(null);
    const handleCalculate = () => {
        if(!origin || !destination) 
            return;

    //mock rouute -replace with API call
    setRoute([origin, destination]);
    };
    return (
        <div className="flex h-screen bg-gray-50">
            <Sidebar role="student"/>
            <main className="flex-1 overflow-y-auto p-6">
            <h1 className="text-2xl font-bold text-nwu-blue mb-6">Safe Route</h1>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="bg-white rounded-xl shadow-sm p-6 space-y"
    );
};import {useState} from 'react';
import {Sidebar} from '../../components/common/Sidebar';
import {MapView} from '../../components/map/MapView';
import {Button} from '../../components/common/Button';
import {ROUTE_WARNING} from '../../utils/constants';
import {AlertTriangle} from 'lucide-react';

export const SafeRoute = () => {
    const [origin, setOrigin] = useState<[number, number] | null>(null);
    const [destination, setDestination] = useState<[number,number] | null>(null);
    const [route, setRoute] = useState<[number,number][] | null>(null);
    const handleCalculate = () => {
        if(!origin || !destination) 
            return;

    //mock rouute -replace with API call
    setRoute([origin, destination]);
    };
    return (
        <div className="flex h-screen bg-gray-50">
            <Sidebar role="student"/>
            <main className="flex-1 overflow-y-auto p-6">
            <h1 className="text-2xl font-bold text-nwu-blue mb-6">Safe Route</h1>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="bg-white rounded-xl shadow-sm p-6 space-y"
    );
};import {useState} from 'react';
import {Sidebar} from '../../components/common/Sidebar';
import {MapView} from '../../components/map/MapView';
import {Button} from '../../components/common/Button';
import {ROUTE_WARNING} from '../../utils/constants';
import {AlertTriangle} from 'lucide-react';

export const SafeRoute = () => {
    const [origin, setOrigin] = useState<[number, number] | null>(null);
    const [destination, setDestination] = useState<[number,number] | null>(null);
    const [route, setRoute] = useState<[number,number][] | null>(null);
    const handleCalculate = () => {
        if(!origin || !destination) 
            return;

    //mock rouute -replace with API call
    setRoute([origin, destination]);
    };
    return (
        <div className="flex h-screen bg-gray-50">
            <Sidebar role="student"/>
            <main className="flex-1 overflow-y-auto p-6">
            <h1 className="text-2xl font-bold text-nwu-blue mb-6">Safe Route</h1>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="bg-white rounded-xl shadow-sm p-6 space-y"
    );
};