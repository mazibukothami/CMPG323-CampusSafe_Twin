import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Shield } from 'lucide-react';
import { Button } from '../../components/common/Button';
import { useAuth } from '../../hooks/useAuth';
import toast from 'react-hot-toast';

export const SecurityLogin = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();
  const { login } = useAuth();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    login(
      { id: '2', email, displayName: 'Security', role: 'security' },
      'mock-token'
    );
    toast.success('Welcome back!');
    navigate('/security');
  };

  return (
    <div className="min-h-screen bg-nwu-blue flex items-center justify-center p-6">
      <div className="bg-white rounded-2xl shadow-xl p-8 w-full max-w-md">
        <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
          <Shield className="w-8 h-8 text-green-600" />
        </div>
        <h1 className="text-2xl font-bold text-center text-gray-900 mb-2">
          Security Login
        </h1>
        <p className="text-center text-gray-500 mb-6">
          Log in with your security credentials
        </p>

        <form onSubmit={handleSubmit} className="space-y-4">
          <input
            type="email"
            placeholder="Staff Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-nwu-blue"
            required
          />
          <input
            type="password"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-nwu-blue"
            required
          />
          <Button type="submit" className="w-full py-3">
            Log In
          </Button>
        </form>

        <button
          onClick={() => navigate('/login/options')}
          className="w-full mt-4 text-sm text-gray-500 hover:text-nwu-blue"
        >
          ← Back to login options
        </button>
      </div>
    </div>
  );
};