import {useNavigate} from 'react-router-dom';
import {Shield, GraduationCap} from 'lucide-react';
export const LoginOptions = () => {
    const navigate = useNavigate();
    return{
        <div className="min-h-screen bg-nwu-blue flex flex-col items-center justify-center p-6">
        <Shield className="w-16 h-16 text-nwu-gold mb-4"/>
        <h1 className="text-2xl font-bold text-white mb-2">CampusSafe Twin</h1>
        <p className="text-white/60 mb-12">Choose your login type</p>
        <div className="w-full max-w-sm space-y-4">
        <button
            onClick={() => navigate('/login/student')}
            className="w-full bg-white p-6 rounded-xl flex items-center gap-4 hover:shadow-lg transition">
            <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
            <GraduationCap className="w-6 h-6 text-blue-600"/>
            </div>
            <div className="text-left">
            <h3 className="font-semibold text-gray-900">Log in as Student</h3>
            <p className="text-sm text-gray-500">Report and view incidents</p>
            </div>
            </button>

            <button>
                onClick={() => navigate('/login/security')}
                className="w-full bg-white p-6 rounded-xl flex items-center gap-4 hover:shadow-lg transition">
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                <Shield className="w-6 h-6 text-green-600"/>
                </div>

            <div className="text-left">
                <h3 className="font-semibold text-gray-900"> Monitor and manage incidents</p>
                </div>
                </button>
                </div>
                </div>
    );
};