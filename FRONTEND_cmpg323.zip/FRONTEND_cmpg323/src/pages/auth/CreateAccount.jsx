import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Shield } from 'lucide-react';
import { Button } from '../../components/common/Button';
import toast from 'react-hot-toast';

export const CreateAccount = () => {
  const navigate = useNavigate();
  const [role, setRole] = useState<'student' | 'security'>('student');
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    password: '',
    confirmPassword: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (formData.password !== formData.confirmPassword) {
      toast.error('Passwords do not match');
      return;
    }
    toast.success('Account created successfully!');
    navigate('/login');
  };

  return (
    <div className="min-h-screen bg-nwu-blue flex items-center justify-center p-6">
      <div className="bg-white rounded-2xl shadow-xl p-8 w-full max-w-md">
        <div className="w-16 h-16 bg-nwu-blue rounded-full flex items-center justify-center mx-auto mb-4">
          <Shield className="w-8 h-8 text-white" />
        </div>
        <h1 className="text-2xl font-bold text-center text-gray-900 mb-2">
          Create Account
        </h1>
        <p className="text-center text-gray-500 mb-6">
          Join CampusSafe Twin
        </p>

        {/* Role Toggle */}
        <div className="flex gap-2 mb-6 bg-gray-100 p-1 rounded-lg">
          <button
            onClick={() => setRole('student')}
            className={`flex-1 py-2 rounded-md text-sm font-medium transition ${
              role === 'student' 
                ? 'bg-white shadow text-nwu-blue' 
                : 'text-gray-500'
            }`}
          >
            Student
          </button>
          <button
            onClick={() => setRole('security')}
            className={`flex-1 py-2 rounded-md text-sm font-medium transition ${
              role === 'security' 
                ? 'bg-white shadow text-nwu-blue' 
                : 'text-gray-500'
            }`}
          >
            Security
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <input
            type="text"
            placeholder="Full Name"
            value={formData.fullName}
            onChange={(e) => setFormData({...formData, fullName: e.target.value})}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-nwu-blue"
            required
          />
          <input
            type="email"
            placeholder="Email"
            value={formData.email}
            onChange={(e) => setFormData({...formData, email: e.target.value})}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-nwu-blue"
            required
          />
          <input
            type="password"
            placeholder="Password"
            value={formData.password}
            onChange={(e) => setFormData({...formData, password: e.target.value})}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-nwu-blue"
            required
          />
          <input
            type="password"
            placeholder="Confirm Password"
            value={formData.confirmPassword}
            onChange={(e) => setFormData({...formData, confirmPassword: e.target.value})}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-nwu-blue"
            required
          />
          <Button type="submit" className="w-full py-3">
            Create Account
          </Button>
        </form>

        <p className="text-center text-sm text-gray-500 mt-6">
          Already have an account?{' '}
          <button 
            onClick={() => navigate('/login')}
            className="text-nwu-blue hover:underline font-medium"
          >
            Login
          </button>
        </p>
      </div>
    </div>
  );
};