import {useState} from 'raect';
import {useNavigate} from 'react-router-dom';
import {Shield} from 'lucide-react';
import {Button} from '../../components/common/Button';
import {useAuth} from '../../hooks/useAuth';
import toast from 'react-hot-toast';

export const LoginDesktop = () => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const navigate = useNavigate();
    const {login} = useAuth();
    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();


        //mock login - replace wth real API call
        if (email === 'student@nwu.ac.za' && password === 'password'){
            login(
                {id: '1', email, displayName: 'Alira', role: 'student'},
                mock-token
            );
            toast.success('Welcome back!');
            navigate('/student');
        }
        else if(email === 'security@mynwu.ac.za' && password === 'password'){
            login(
                {id: '2', email, displayName: 'Security', role: 'security'},
                'mock-token'
            );
            toast.success('Welcome back!');
            navigate('/security');
        }
        else
        {
            toast.error('Invalid username or password');
        }
    };

    return (
        <div className="min-h-screen flex">
            {/* Left: Branding */}
        <div className="hidden lg:flex lg:w-1/2 bg-nwu-blue text-white p-12 flex-col justify-between">
        <div className="flex items-center gap-3">
        <Shield className="w-10 h-10 text-nwu-gold"/>
        <div>
            <h1 className="text-2xl font-bold">CampusSafe Twin</h1>
            <p className="text-white/60">North-West University</p>
        </div>
        </div>
        <div>
            <h2 className="text-4xl font-bold mb-4">A digital twin for campus safety</h2>
            <p className="text-white/70 text-lg">Report incidents, monitor hotspots, and find safer routes across campus</p>
        </div>
        <p className="text-white/40 text-sm"> c 2026 North-West University. All rights reserved</p>
        </div>
        
        {/*Right: Login Form*/}
        <div className="w-full lg:w-1/2 flex items-center justify-center p-8">
        <div className="w-full max-w-md">
            <h2 className="text-3xl font-bold text-gray-900 mb-2">Welcome Back</h2>
            <p className="text-gray-500 mb-8">Log in to your accoutnto continue</p>
            <form on Submit={handleSubmit} className="space-y-4">
            <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                    Email address
                    </label>
                    <input
                        type="email"
                        value={email}
                        onChange={(e) => setEmail(
                            e.target.value
                        )}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-nwu-blue focus:border-transparent"
                    placeholder="student@nwu.ac.za"
                    required
                    />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                            Password
                            </label>
                            <input
                                type="password"
                                value={password}
                                onChange={(e) => setPassword(e.target.value)}
                                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-nwu-blue focus:border-transparent"
                                    placeholder="**********"
                                    required
                                    />
                                </div>
                                <div className="flex items-center justify-between">
                                    <label className="flex items-center gap-2 text-sm text-gray-600">
                                    <input type="checkbox" className="rounded"/>
                                    Remember me
                                    </label>
                                    <a href="#" className="text-sm text-nwu-blue hover:underline">
                                        Forgot password?
                                        </a>
                                        </div>
                                        <Button type="submit" className="w-full py-3">
                                            Log In
                                        </Button>
                                        </form>

                                        <div className="mt-6 text-center text-sm text-gray-500">
                                            Don't have an account?{' '}
                                            <a href="/register" className="text-nwu-blue hover:underline font-medium">
                                            Create Account 
                                            </a>
                                            </div>
                                            </div>
                                            </div>
                                            </div>
    );
};