export const CAMPUS_CENTER: [number, number] = [-26.6886, 27.0925];

export const INCIDENT_CATEGORIES = [
  { value: 'theft', label: 'Theft' },
  { value: 'medical', label: 'Medical' },
  { value: 'suspicious', label: 'Suspicious Activity' },
  { value: 'vandalism', label: 'Vandalism' },
  { value: 'harassment', label: 'Harassment' },
  { value: 'other', label: 'Other' },
] as const;

export const INCIDENT_STATUSES = [
  { value: 'new', label: 'New', color: '#EF4444' },
  { value: 'acknowledged', label: 'Acknowledged', color: '#F59E0B' },
  { value: 'in_progress', label: 'In Progress', color: '#3B82F6' },
  { value: 'resolved', label: 'Resolved', color: '#10B981' },
  { value: 'invalid', label: 'Invalid', color: '#6B7280' },
  { value: 'duplicate', label: 'Duplicate', color: '#8B5CF6' },
] as const;

export const ROUTE_WARNING = 
  'This route is a recommendation based on reported incidents. ' +
  'It is not a guarantee of safety. Always use your own judgement.';