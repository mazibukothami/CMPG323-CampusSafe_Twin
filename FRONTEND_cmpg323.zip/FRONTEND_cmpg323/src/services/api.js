import axios from 'axios';

const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

export const api = axios.create({
  baseURL: API_BASE_URL,
  headers: { 'Content-Type': 'application/json' },
});

api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Mock data for development
export const mockIncidents = [
  {
    id: '1',
    reporterId: 'student-1',
    category: 'theft' as const,
    description: 'Phone stolen near library entrance',
    latitude: -26.6886,
    longitude: 27.0925,
    status: 'new' as const,
    reportedAt: new Date().toISOString(),
    referenceNumber: 'CS-2026-0001',
  },
  {
    id: '2',
    reporterId: 'student-2',
    category: 'suspicious' as const,
    description: 'Suspicious person near parking lot B',
    latitude: -26.6890,
    longitude: 27.0930,
    status: 'acknowledged' as const,
    reportedAt: new Date().toISOString(),
    referenceNumber: 'CS-2026-0002',
  },
];