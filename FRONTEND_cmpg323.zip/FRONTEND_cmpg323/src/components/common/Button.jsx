import {ButtonHTMLAttributes, ReactNode} from 'react';
interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
    variant?: 'primary' | 'secondary' | 'danger';
    children: ReactNode;
}
export const Button = ({
    variant = 'primary',
    children,
    className = '',
    ...props
}: ButtonProps) => {
    const baseStyles = 'px-4 py-2 rounded-lg font-medium transition-colors';
    const variants = { 
        primary: 'bg-nwu-blue text-white hover:bg-nwu-blue-light',
        secondary: 'bg-gray-200 text-gray-800 hover:bg-gray-300',
        danger: 'bg-red-500 text-white hover:bg-red-600',
    };
    return (
        <button
            className={'${baseStyles} ${variants[variant]} ${className}'}
            {...props}
        >
        {children}
        </button>
    );
};