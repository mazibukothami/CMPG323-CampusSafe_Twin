import { IncidentStatus } from '../../types';
import { INCIDENT_STATUSES } from '../../utils/constants';

interface StatusBadgeProps {
  status: IncidentStatus;
}

export const StatusBadge = ({ status }: StatusBadgeProps) => {
  const statusConfig = INCIDENT_STATUSES.find(s => s.value === status);
  
  return (
    <span
      className="px-2 py-1 rounded-full text-xs font-medium text-white"
      style={{ backgroundColor: statusConfig?.color || '#6B7280' }}
    >
      {statusConfig?.label || status}
    </span>
  );
};