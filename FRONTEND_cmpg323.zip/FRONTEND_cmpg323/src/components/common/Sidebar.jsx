import { Link, useLocation } from 'react-router-dom';
import { 
  LayoutDashboard, 
  AlertTriangle, 
  Route, 
  Bell, 
  Settings,
  LogOut,
  Shield,
  BarChart3,
  List
} from 'lucide-react';
import { useAuth } from '../../hooks/useAuth';

interface SidebarProps {
  role: 'student' | 'security';
}

export const Sidebar = ({ role }: SidebarProps) => {
  const location = useLocation();
  const { logout } = useAuth();

  const studentNav = [
    { path: '/student', label: 'Dashboard', icon: LayoutDashboard },
    { path: '/student/report', label: 'Report Incident', icon: AlertTriangle },
    { path: '/student/safe-route', label: 'Safe Route', icon: Route },
  ];

  const securityNav = [
    { path: '/security', label: 'Dashboard', icon: LayoutDashboard },
    { path: '/security/incidents', label: 'Incidents', icon: List },
    { path: '/security/analytics', label: 'Analytics', icon: BarChart3 },
  ];

  const navItems = role === 'student' ? studentNav : securityNav;

  return (
    <aside className="w-64 bg-nwu-blue text-white h-screen flex flex-col">
      <div className="p-6 border-b border-white/10">
        <div className="flex items-center gap-2">
          <Shield className="w-8 h-8 text-nwu-gold" />
          <div>
            <h1 className="font-bold">CampusSafe Twin</h1>
            <p className="text-xs text-white/60">North-West University</p>
          </div>
        </div>
      </div>

      <nav className="flex-1 p-4 space-y-1">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = location.pathname === item.path;
          return (
            <Link
              key={item.path}
              to={item.path}
              className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                isActive 
                  ? 'bg-white/15 text-white' 
                  : 'text-white/70 hover:bg-white/10 hover:text-white'
              }`}
            >
              <Icon className="w-5 h-5" />
              <span>{item.label}</span>
            </Link>
          );
        })}
      </nav>

      <div className="p-4 border-t border-white/10">
        <button
          onClick={logout}
          className="flex items-center gap-3 px-4 py-3 text-white/70 hover:text-white w-full"
        >
          <LogOut className="w-5 h-5" />
          <span>Logout</span>
        </button>
      </div>
    </aside>
  );
};