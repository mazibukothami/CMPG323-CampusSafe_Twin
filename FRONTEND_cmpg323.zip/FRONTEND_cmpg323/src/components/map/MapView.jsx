import {MapContainer, TileLayer, Marker, Popup} from 'react-leaflet';
import L from 'leaflet';
import {Incident} from '../../types';
import {CAMPUS_CENTER} from '../../utils/constants';
import {StatusBadge} from '../common/StatusBadge';

//fix leaflet default marker icons
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
    iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
    iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
    shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

interface MapViewProps{
    incidents?: Incident[];
    heigh?: string;
    onMapClick?: (lat: number, lng: number) => void;
    selectedPosition?: [number, number] | null;
    routeCoordinates?: [number, number][];
}
export const MapView = ({
    incidents = [],
    height = '400px',
    onMapClick,
    selectedPosition,
    routeCoordinates,
}: MapViewProps) => {
    return(
        <MapContainer
            center={CAMPUS_CENTER}
            zoom={16}
            style={{height, width: '100%', borderRadius: '8px'}}
            eventHandlers={{
                click: (e) => {
                    if (onMapClick) {
                        onMapClick(e.latlng.lat, e.latlng,lng);
                    }
                },
            }}
            >
            <TileLayer
                url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
                />

                {incidents.map((incident) => (
                    <Marker
                        key={incident.id}
                        position={[incident.latitude, incident.longitude]}
                    >
                    <Popup>
                        <div className="p-2">
                            <h3 className="font-semiboldl capitalize">{incident.category}</h3>
                            <p className="text-sm text-gray-600">{incident.description}</p>
                            <div className="mt-2">
                            <StatusBadge status={incidents.status}/>
                            </div>
                            <p className="text-xs text-gray-400 mt-2">
                            {new Date(incident.reportedAt).toLocaleString()}
                            </p>
                            </div>
                            </Popup>
                            </Marker>
                ))}
                {selectedPosition && (
                    <Marker position={selectedPosition}>
                    <Popup> selected Location</Popup>
                    </Marker>
                )}
                </MapContainer>
    );
};