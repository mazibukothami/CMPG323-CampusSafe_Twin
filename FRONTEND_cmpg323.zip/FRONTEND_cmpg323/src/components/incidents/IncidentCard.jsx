import {Incident} from '../../types'
import {StatusBadge} from '../common/StatusBadge';
import {MapPin, Clock} from 'lucide-react';
interface IncidentCardProps{
    incident: Incident;
}
export const IncidentCard = ({incident} :
    IncidentCardProps) => {
        return(
            <div className="border border-gray-200 rounded-lg p-3 hover:bg-gray-50 transition">
                <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                        <span className="font-medium capitalize text-gray-900">
                            {incident.category}
                            </span>
                            <StatusBadge status={incident.status}/>
            </div>
            <p className="text-sm text-gray-600 mb-2">{incident.description}</p>
            <div className="flex items-center gap-4 text-xs text-gray-400">
                <span className="flex items-center gap-1">
                    <MapPin className="w-3 h-3"/>
                    {incident.latitude.toFixed(4)}, {incident.longitude.toFixed(4)}
                    </span>
                    <span className="flex items-center gap-1">
                        <Clock className="w-3 h-3"/>
                        {new Date(incident.reportedAt).toLocaleTimeString()}

                        </span>
                        </div>
                        </div>
                        </div>
                        </div>
        );
    };