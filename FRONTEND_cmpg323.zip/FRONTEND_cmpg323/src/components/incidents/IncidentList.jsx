import { useState } from "react";
import { Sidebar } from "../../components/common/Sidebar";
import { StatusBadge } from "../../components/common/StatusBadge";
import { mockIncidents } from "../../services/api";
import { INCIDENT_CATEGORIES, INCIDENT_STATUSES } from "../../utils/constants";

export const IncidentList = () => {
  const [incidents] = useState(mockIncidents);
  const [categoryFilter, setCategoryFilter] = useState(" ");
  const [statusFilter, setStatusFilter] = useState("");
  const filtered = incidents.filter((i) => {
    if (categoryFilter && i.category !== categoryFilter) return false;
    if (statusFilter && i.status !== statusFilter) return false;
    return true;
  });

  return (
    <div className="flex h-screen bg-gray-50">
      <Sidebar role="security" />
      <main className="flex-1 overflow-y-auto p-6">
        <h1 className="text-2xl font-bold text-nwu-blue mb-6">All Incidents</h1>
        <div className="bg-white rounded-xl shadow-sm p-4 mb-6">
          <div className="flex flex-wrap gap-4">
            <select
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
              className="px-4 py-2 border border-gray-300 rounded-lg"
            >
              <option value="">All Categories</option>
              {INCIDENT_CATEGORIES.map((c) => (
                <option key={c.value} value={c.value}>
                  {c.label}
                </option>
              ))}
            </select>

            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="px-4 py-2 border border-gray-300 rounded-lg"
            >
              <option value="">All Statuses</option>
              {INCIDENT_STATUSES.map((s) => (
                <option key={s.value} value={s.value}>
                  {s.label}
                </option>
              ))}
            </select>
          </div>
        </div>
        <div className="bg-white rounded-xl shadow-sm overflow-hidden">
          <table className="w-full">
            <thead className="bg-gray-50 border-b">
              <tr>
                <th className="text-left px-6 py-3 text-xs font-medium text-gray-500 uppercase">
                  Category
                </th>
                <th className="text-left px-6 py-3 text-xs font-medium text-gray-500 uppercase">
                  Description
                </th>
                <th className="text-left px-6 py-3 text-xs font-medium text-gray-500 uppercase">
                  Status
                </th>
                <th className="text-left px-6 py-3 text-xs font-medium text-gray-500 uppercase">
                  Reported
                </th>
              </tr>
            </thead>

            <tbody className="divide-y">
              {filter.map((incident) => (
                <tr key={incident.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 capitalize text-gray-900">
                    {incident.category}
                  </td>
                  <td className="px-6 py-4 text-gray-600">
                    {incident.description}
                  </td>
                  <td className="px-6 py-4">
                    <StatusBadge status={incident.status} />
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-500">
                    {new Date(incident.reportedAt).toLocaleString()}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </main>
    </div>
  );
};